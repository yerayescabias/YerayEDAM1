package model;

public class Saskipartida extends Partida {
    
}
